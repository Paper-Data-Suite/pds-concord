"Teacher-facing Activity Packet generation, review, recovery, and reprint."

from __future__ import annotations

from pathlib import Path

from pds_core.classes import load_class_roster
from pds_core.rosters import student_display_name, student_sort_name
from pds_core.workspace import resolve_workspace_root

from concord.menu_context import CancelMenuAction, MenuSessionContext
from concord.menu_navigation import (
    ConcordMenuChoice,
    NavigationChoice,
    navigation_hint_with_help,
    parse_menu_navigation,
)
from concord.menu_prompts import (
    confirm_write,
    prompt_text,
    select_one,
    show_result,
)
from concord.menu_teacher_history import (
    distinguish_equal_labels,
    teacher_planned_date,
    teacher_recorded_instant,
)
from concord.menu_ui import (
    clear_screen,
    pause_for_user,
    print_menu_header,
    print_navigation,
)
from concord.models import (
    PacketComponent,
    SubjectReference,
    TemplateRenderingInput,
    TemplateSubjectResolutionExpectation,
)
from concord.workflows import (
    ActivitySummary,
    SessionSummary,
    list_sessions,
    open_rendered_packet_output,
    open_rendered_packet_output_directory,
)
from concord.workflows.errors import ConcordWorkflowError
from concord.workflows.group import list_groups
from concord.workflows.packet import PacketSummary, get_packet, list_packets
from concord.workflows.packet_generation import (
    PacketGenerationSummary,
    list_packet_generations,
)
from concord.workflows.packet_instance import (
    PacketInstanceSummary,
    list_packet_instances,
    show_packet_instance,
)
from concord.workflows.packet_instantiation import (
    PacketComponentChoice,
    PacketRenderingBinding,
    PacketSubjectBinding,
    PreparedPacketInstantiation,
    PreparePacketInstantiationRequest,
    prepare_packet_instantiation,
)
from concord.workflows.packet_instantiation_commit import (
    PacketInstantiationPartialSuccessError,
    commit_packet_instantiation,
    resume_packet_instantiation,
)
from concord.workflows.packet_rendering import (
    PacketGenerationLifecyclePartialSuccessError,
    PacketGenerationRenderPartialSuccessError,
    PacketRenderPartialSuccessError,
    RenderPacketGenerationRequest,
    RenderPacketGenerationResult,
    RenderPacketInstanceRequest,
    render_packet_generation,
    render_packet_instance,
)


def launch_packet_generation_menu(
    activity: ActivitySummary,
    state: MenuSessionContext,
) -> None:
    """Run the Activity-specific Packet generation and recovery menu."""
    while True:
        clear_screen()
        print_menu_header("Prepare / Generate Packet")
        print(f"Activity: {activity.title}")
        print()
        print("1. Preview and generate a Packet")
        print("2. List generated Packet Instances")
        print("3. Inspect a Packet Instance")
        print("4. Render / reprint a complete generation")
        print("5. Render / reprint one Packet Instance")
        print("6. Resume incomplete route preparation")
        print("7. Open a rendered Packet")
        print("8. Open rendered Packet folder")
        print_navigation()
        print()
        choice = input("Select an option: ").strip()
        navigation = parse_menu_navigation(choice)
        if navigation is ConcordMenuChoice.HELP:
            _help()
        elif navigation is NavigationChoice.BACK:
            return
        elif choice == "1":
            _generate(activity, state)
        elif choice == "2":
            _list_instances(activity)
        elif choice == "3":
            _inspect_instance(activity)
        elif choice == "4":
            _render_generation(activity, state)
        elif choice == "5":
            _render_instance(activity, state)
        elif choice == "6":
            _resume_generation(activity)
        elif choice == "7":
            _open_ready_packet(activity)
        elif choice == "8":
            _open_ready_folder(activity)
        else:
            print(navigation_hint_with_help())
            pause_for_user()


def _help() -> None:
    clear_screen()
    print_menu_header("Packet Generation Help")
    print("Choose one exact active Packet Version and one explicit Session.")
    print("Concord resolves audience targets before any generation state is written.")
    print(
        "Relationship-aware peer review asks you to assign each reviewed "
        "Student or Group explicitly."
    )
    print("The preview shows exact counts, diagnostics, and a review digest.")
    print("Type GENERATE only after reviewing the resolved generation.")
    print("A retry reuses durable Packet, Artifact, Page, and route identities.")
    print("Use complete-generation render/reprint for the ordinary class-set workflow.")
    print("Reprint never allocates a replacement route for an existing Packet.")
    print()
    pause_for_user()


def _generate(
    activity: ActivitySummary,
    state: MenuSessionContext,
    selected_packet: PacketSummary | None = None,
) -> None:
    try:
        summary = (
            _choose_active_packet() if selected_packet is None else selected_packet
        )
        detail = get_packet(summary.packet_definition_id)
        current_version_id = detail.summary.current_packet_version_id
        if current_version_id is None:
            raise ConcordWorkflowError("Selected Packet has no active current Version.")
        version = next(
            (
                item
                for item in detail.versions
                if item.packet_version_id == current_version_id
            ),
            None,
        )
        if version is None:
            raise ConcordWorkflowError(
                "Selected Packet current Version is unavailable."
            )
        session = _choose_session(activity)
        choices = _component_choices(version.components)
        prepared = prepare_packet_instantiation(
            PreparePacketInstantiationRequest(
                class_id=activity.class_id,
                activity_id=activity.activity_id,
                session_id=session.session_id,
                packet_definition_id=summary.packet_definition_id,
                packet_version_id=version.packet_version_id,
                actor=state.require_actor(),
                component_choices=choices,
            )
        )
        bindings = _prompt_missing_bindings(prepared)
        if bindings:
            prepared = prepare_packet_instantiation(
                PreparePacketInstantiationRequest(
                    class_id=activity.class_id,
                    activity_id=activity.activity_id,
                    session_id=session.session_id,
                    packet_definition_id=summary.packet_definition_id,
                    packet_version_id=version.packet_version_id,
                    actor=state.require_actor(),
                    component_choices=choices,
                    rendering_bindings=bindings,
                )
            )
        subject_bindings = _prompt_missing_subject_bindings(prepared)
        if subject_bindings:
            prepared = prepare_packet_instantiation(
                PreparePacketInstantiationRequest(
                    class_id=activity.class_id,
                    activity_id=activity.activity_id,
                    session_id=session.session_id,
                    packet_definition_id=summary.packet_definition_id,
                    packet_version_id=version.packet_version_id,
                    actor=state.require_actor(),
                    component_choices=choices,
                    rendering_bindings=bindings,
                    subject_bindings=subject_bindings,
                )
            )
        lines = _preview_lines(prepared)
        if not prepared.ready_for_commit:
            show_result("Packet Preview", lines)
            return
        if not confirm_write("Generate Packet", "GENERATE", lines):
            return
        committed = commit_packet_instantiation(prepared)
        rendered = render_packet_generation(
            RenderPacketGenerationRequest(
                class_id=activity.class_id,
                activity_id=activity.activity_id,
                generation_id=committed.generation_id,
                actor=state.require_actor(),
            )
        )
        _post_generation_open_menu(activity, rendered)
    except CancelMenuAction:
        return
    except PacketInstantiationPartialSuccessError as error:
        show_result(
            "Packet Generation Partial Success",
            (
                str(error),
                f"Generation: {error.result.generation_id}",
                f"Stage: {error.stage}",
                (
                    f"Routes: {error.result.routes_verified}/"
                    f"{error.result.routes_expected}"
                ),
                "Use Resume incomplete route preparation before regenerating.",
            ),
        )
    except PacketGenerationRenderPartialSuccessError as error:
        show_result(
            "Packet Rendering Partial Success",
            (
                str(error),
                f"Generation: {error.generation_id}",
                f"Completed Packet outputs: {len(error.completed)}",
                "Use Render / reprint for any incomplete Packet Instance.",
            ),
        )
    except PacketRenderPartialSuccessError as error:
        show_result(
            "Packet Rendering Partial Success",
            (
                str(error),
                f"Output: {error.result.output_path}",
                "The PDF is durable; retrying will reconcile lifecycle state.",
            ),
        )
    except Exception as error:
        show_result("Packet Generation Error", (str(error),))


def _post_generation_open_menu(
    activity: ActivitySummary,
    rendered: RenderPacketGenerationResult,
) -> None:
    # Offer read-only local Open actions for the just-completed generation.
    while True:
        clear_screen()
        print_menu_header("Packet Generation Result")
        print("Packet generation completed.")
        print(f"Ready PDFs: {len(rendered.packets)}")
        print(f"Pages: {rendered.page_count}")
        print(f"Routes: {rendered.route_count}")
        print()
        print("1. Open one rendered Packet")
        print("2. Open rendered Packet folder")
        print("3. Finish")
        print_navigation()
        print()
        choice = input("Select an option: ").strip()
        navigation = parse_menu_navigation(choice)
        if navigation is ConcordMenuChoice.HELP:
            clear_screen()
            print_menu_header("Packet Generation Result Help")
            print("Open uses the completed generation's current canonical outputs.")
            print("Concord verifies the selected PDF before requesting the viewer.")
            print("Open does not rerender, reprint, repair, or record viewed state.")
            print()
            pause_for_user()
        elif navigation is NavigationChoice.BACK or choice == "3":
            return
        elif choice == "1":
            _open_ready_packet(
                activity,
                generation_id=rendered.generation_id,
            )
        elif choice == "2":
            _open_ready_folder(
                activity,
                generation_id=rendered.generation_id,
            )
        else:
            print(navigation_hint_with_help())
            pause_for_user()


def generate_saved_packet(
    activity: ActivitySummary,
    state: MenuSessionContext,
    packet: PacketSummary,
) -> None:
    """Prepare one teacher-selected saved Packet through the normal review flow."""
    _generate(activity, state, selected_packet=packet)


def _choose_active_packet() -> PacketSummary:
    packets = tuple(
        item
        for item in list_packets()
        if item.status == "active" and item.current_packet_version_id is not None
    )
    if not packets:
        raise ConcordWorkflowError("No active reusable Packets are available.")
    return select_one(
        "Choose a Packet",
        packets,
        tuple(
            f"{item.name} ({item.packet_definition_id}) - "
            f"{item.current_packet_version_id}"
            for item in packets
        ),
        help_text="Choose the reusable Packet to instantiate for this Activity.",
    )


def _choose_session(activity: ActivitySummary) -> SessionSummary:
    sessions = tuple(
        item
        for item in list_sessions(activity.class_id, activity.activity_id)
        if item.status not in {"cancelled", "archived"}
    )
    if not sessions:
        raise ConcordWorkflowError("No usable Sessions are available.")
    return select_one(
        "Choose a Session",
        sessions,
        tuple(
            f"{item.sequence}. {item.label or item.session_id} [{item.status}]"
            for item in sessions
        ),
        help_text="Issue #62 requires one explicit Session for Packet generation.",
    )


def _component_choices(
    components: tuple[PacketComponent, ...],
) -> tuple[PacketComponentChoice, ...]:
    choices: list[PacketComponentChoice] = []
    for component in components:
        if (
            component.requirement_level == "conditional"
            and component.condition is not None
            and component.condition.condition_kind == "teacher_choice"
        ):
            include = select_one(
                "Conditional Packet Component",
                (True, False),
                (
                    f"Include {component.label or component.packet_component_id}",
                    f"Omit {component.label or component.packet_component_id}",
                ),
                help_text=(
                    "This Packet component explicitly requires a teacher yes/no "
                    "choice for this generation."
                ),
            )
            choices.append(
                PacketComponentChoice(
                    packet_component_id=component.packet_component_id,
                    include=include,
                )
            )
    return tuple(choices)


def _prompt_missing_bindings(
    prepared: PreparedPacketInstantiation,
) -> tuple[PacketRenderingBinding, ...]:
    missing = []
    seen: set[tuple[str, str]] = set()
    for diagnostic in prepared.diagnostics:
        if (
            diagnostic.code == "required_rendering_input_missing"
            and diagnostic.packet_component_id is not None
            and diagnostic.input_key is not None
        ):
            key = (diagnostic.packet_component_id, diagnostic.input_key)
            if key not in seen:
                seen.add(key)
                missing.append(key)
    if not missing:
        return ()

    definitions = _rendering_input_index(prepared)
    bindings: list[PacketRenderingBinding] = []
    for component_id, input_key in missing:
        definition = definitions.get((component_id, input_key))
        value_kind = "text" if definition is None else definition.value_kind
        raw = prompt_text(
            "Packet Rendering Input",
            input_key.replace("_", " ").title(),
            help_text=(
                f"Enter the teacher-controlled {value_kind} value for "
                f"component {component_id}."
            ),
        )
        assert raw is not None
        value: str | int | bool = raw
        if value_kind == "integer":
            try:
                value = int(raw)
            except ValueError as error:
                raise ConcordWorkflowError(
                    f"{input_key} requires an integer."
                ) from error
        elif value_kind == "boolean":
            normalized = raw.casefold()
            if normalized not in {"true", "false", "yes", "no"}:
                raise ConcordWorkflowError(
                    f"{input_key} requires true/false or yes/no."
                )
            value = normalized in {"true", "yes"}
        bindings.append(
            PacketRenderingBinding(
                packet_component_id=component_id,
                input_key=input_key,
                value=value,
            )
        )
    return tuple(bindings)


def _prompt_missing_subject_bindings(
    prepared: PreparedPacketInstantiation,
) -> tuple[PacketSubjectBinding, ...]:
    """Collect explicit peer-review Subjects without inferring pairings."""
    missing: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for diagnostic in prepared.diagnostics:
        if (
            diagnostic.code == "artifact_subject_binding_required"
            and diagnostic.packet_component_id is not None
            and diagnostic.target_key is not None
        ):
            key = (diagnostic.packet_component_id, diagnostic.target_key)
            if key not in seen:
                seen.add(key)
                missing.append(key)
    if not missing:
        return ()

    root = resolve_workspace_root()
    roster = load_class_roster(root, prepared.request.class_id)
    students = tuple(sorted(roster.students, key=student_sort_name))
    groups = tuple(
        item
        for item in list_groups(
            prepared.request.class_id,
            prepared.request.activity_id,
            workspace_root=root,
        )
        if item.status in {"planned", "active"}
    )
    expectations = _explicit_subject_expectation_index(prepared)
    targets = {item.target_key: item for item in prepared.target_plans}
    bindings: list[PacketSubjectBinding] = []

    for component_id, target_key in missing:
        expectation = expectations.get(component_id)
        if expectation is None:
            raise ConcordWorkflowError(
                "Packet preview requested an explicit Subject for a component "
                "without an explicit Subject-resolution contract."
            )
        target = targets.get(target_key)
        if target is None:
            raise ConcordWorkflowError(
                "Packet preview Subject assignment target is no longer available."
            )
        reviewer_id = (
            None
            if target.target_context.participant_reference is None
            else target.target_context.participant_reference.participant_id
        )
        available_kinds = tuple(
            kind
            for kind in ("core_student", "concord_group")
            if kind in expectation.subject_kinds
            and (
                (
                    kind == "core_student"
                    and any(
                        expectation.allow_target_subject_match
                        or item.student_id != reviewer_id
                        for item in students
                    )
                )
                or (kind == "concord_group" and bool(groups))
            )
        )
        if not available_kinds:
            raise ConcordWorkflowError(
                "No eligible reviewed Subjects are available for this "
                "relationship-aware Packet component."
            )
        if len(available_kinds) == 1:
            subject_kind = available_kinds[0]
        else:
            subject_kind = select_one(
                "Choose Reviewed Subject Type",
                available_kinds,
                tuple(
                    "Student" if item == "core_student" else "Group"
                    for item in available_kinds
                ),
                help_text=(
                    "Choose whether this reviewer is evaluating one student or "
                    "one Activity Group. Concord will not infer a pairing."
                ),
            )

        reviewer_label = target.participant_print_label or "this reviewer"
        if subject_kind == "core_student":
            candidates = tuple(
                item
                for item in students
                if expectation.allow_target_subject_match
                or item.student_id != reviewer_id
            )
            selected = select_one(
                "Assign Review Subject",
                candidates,
                tuple(student_display_name(item) for item in candidates),
                help_text=(
                    f"Choose the student reviewed by {reviewer_label}. "
                    "No reviewer/reviewee pairing is inferred automatically."
                ),
            )
            subject = SubjectReference(
                subject_kind="core_student",
                subject_id=selected.student_id,
                owning_system="core",
            )
        else:
            selected_group = select_one(
                "Assign Review Subject",
                groups,
                tuple(f"{item.label} [{item.status}]" for item in groups),
                help_text=(
                    f"Choose the Activity Group reviewed by {reviewer_label}. "
                    "Group membership is not expanded into student Subjects."
                ),
            )
            subject = SubjectReference(
                subject_kind="concord_group",
                subject_id=selected_group.group_id,
                owning_system="concord",
            )
        bindings.append(
            PacketSubjectBinding(
                packet_component_id=component_id,
                target_key=target_key,
                subject_reference=subject,
            )
        )
    return tuple(bindings)


def _explicit_subject_expectation_index(
    prepared: PreparedPacketInstantiation,
) -> dict[str, TemplateSubjectResolutionExpectation]:
    versions = {
        source.template_version_id: source.template_version
        for source in prepared.template_sources
    }
    result: dict[str, TemplateSubjectResolutionExpectation] = {}
    for component in prepared.packet_version.components:
        if component.template_version_id is None:
            continue
        version = versions.get(component.template_version_id)
        if version is None:
            continue
        expectation = version.default_subject_expectation
        if (
            isinstance(expectation, TemplateSubjectResolutionExpectation)
            and expectation.resolution_mode == "explicit"
        ):
            result[component.packet_component_id] = expectation
    return result


def _rendering_input_index(
    prepared: PreparedPacketInstantiation,
) -> dict[tuple[str, str], TemplateRenderingInput]:
    versions = {
        source.template_version_id: source.template_version
        for source in prepared.template_sources
    }
    result: dict[tuple[str, str], TemplateRenderingInput] = {}
    for component in prepared.packet_version.components:
        if component.template_version_id is None:
            continue
        version = versions.get(component.template_version_id)
        if version is None:
            continue
        for item in version.rendering_inputs:
            result[(component.packet_component_id, item.input_key)] = item
    return result


def _preview_lines(
    prepared: PreparedPacketInstantiation,
) -> tuple[str, ...]:
    lines = [
        f"Packet: {prepared.packet_definition.name}",
        f"Packet Version: {prepared.packet_version.packet_version_id}",
        f"Activity: {prepared.activity.activity_id}",
        f"Session: {prepared.session.label or prepared.session.session_id}",
        f"Generation date: {prepared.generation_date}",
        f"Packet Instances: {prepared.packet_instance_count}",
        f"Artifacts: {prepared.artifact_count}",
        f"Pages: {prepared.page_count}",
        f"Routes: {prepared.route_count}",
        f"Review digest: {prepared.review_digest}",
        "",
        "Components:",
    ]
    for component in prepared.component_previews:
        lines.append(
            f"{component.sequence}. {component.packet_component_id}: "
            f"{component.disposition}; targets "
            f"{component.included_target_count}/{component.eligible_target_count}; "
            f"artifacts {component.artifact_count}; pages {component.page_count}"
        )
    lines.append("")
    lines.append("Resolved targets:")
    lines.extend(
        f"{target.target_key}: {len(target.artifacts)} artifact(s)"
        for target in prepared.target_plans
    )
    relationships = _relationship_preview_lines(prepared)
    if relationships:
        lines.append("")
        lines.append("Relationships:")
        lines.extend(relationships)
    if prepared.diagnostics:
        lines.append("")
        lines.append("Diagnostics:")
        lines.extend(
            (
                ("BLOCKING " if item.blocking else "NOTICE ")
                + f"{item.code}: {item.message}"
            )
            for item in prepared.diagnostics
        )
    return tuple(lines)


def _relationship_preview_lines(
    prepared: PreparedPacketInstantiation,
) -> tuple[str, ...]:
    """Render reviewed peer/observer relationships without exposing raw IDs."""
    lines: list[str] = []
    seen: set[str] = set()
    for target in prepared.target_plans:
        target_label = target.participant_print_label
        if target_label is None:
            continue
        for artifact in target.artifacts:
            subject_label = artifact.subject_print_label
            if subject_label is None:
                continue
            if artifact.proposed_subject_role == "reviewed_subject":
                input_keys = {item.input_key for item in artifact.rendering_inputs}
                subject_role = (
                    "Reviewee"
                    if "reviewee_display_label" in input_keys
                    else "Reviewed"
                )
                line = (
                    f"Reviewer: {target_label} | "
                    f"{subject_role}: {subject_label}"
                )
            elif (
                artifact.authorship_mode == "observer"
                and artifact.proposed_subject_role == "session_context"
            ):
                line = f"Observer: {target_label} | Observed: {subject_label}"
            else:
                continue
            if line not in seen:
                seen.add(line)
                lines.append(line)
    return tuple(lines)


def show_prepared_materials(activity: ActivitySummary) -> None:
    """Show a low-density, read-only summary of prepared classroom materials."""
    try:
        items = list_packet_instances(activity.class_id, activity.activity_id)
        if not items:
            show_result(
                "Prepared Materials",
                ("No classroom materials have been prepared yet.",),
            )
            return

        ready_count = sum(
            1 for item in items if item.generation_status == "generated"
        )
        attention_count = len(items) - ready_count
        lines = [
            f"Prepared sets: {len(items)}",
            f"Ready to print: {ready_count}",
        ]
        if attention_count:
            lines.append(f"Need attention: {attention_count}")

        filenames = tuple(
            dict.fromkeys(
                Path(item.output_relative_path).name
                for item in items
                if item.output_relative_path
            )
        )
        if filenames:
            lines.append("")
            lines.append("Files:")
            lines.extend(filenames)

        show_result("Prepared Materials", tuple(lines))
    except Exception as error:
        show_result("Prepared Materials", (str(error),))


def _teacher_instance_labels(
    activity: ActivitySummary,
    items: tuple[PacketInstanceSummary, ...],
) -> tuple[str, ...]:
    """Return privacy-minimized teacher labels without exposing target IDs."""
    student_labels: dict[str, str] = {}
    group_labels: dict[str, str] = {}
    try:
        root = resolve_workspace_root()
        roster = load_class_roster(root, activity.class_id)
        student_labels = {
            student.student_id: student_display_name(student)
            for student in roster.students
        }
    except Exception:
        # A display-label lookup failure must not turn routine browsing into
        # a raw-ID disclosure. Fall back to audience-kind labels instead.
        student_labels = {}
    try:
        group_labels = {
            group.group_id: group.label
            for group in list_groups(activity.class_id, activity.activity_id)
        }
    except Exception:
        group_labels = {}

    labels: list[str] = []
    for item in items:
        target_kind, separator, target_id = item.target_key.partition(":")
        if not separator:
            label = "Prepared material"
        elif target_kind == "participant":
            label = student_labels.get(target_id, "Participant")
        elif target_kind == "group":
            label = group_labels.get(target_id, "Group")
        elif target_kind == "activity":
            label = "Whole Activity"
        elif target_kind == "teacher":
            label = "Teacher"
        elif target_kind == "role":
            label = "Role-targeted material"
        else:
            label = "Prepared material"
        labels.append(label)
    return tuple(labels)


def _ready_packet_instances(
    activity: ActivitySummary,
    *,
    generation_id: str | None = None,
) -> tuple[PacketInstanceSummary, ...]:
    return tuple(
        item
        for item in list_packet_instances(
            activity.class_id,
            activity.activity_id,
            generation_id=generation_id,
        )
        if item.generation_status == "generated"
    )


def _ready_instance_labels(
    activity: ActivitySummary,
    items: tuple[PacketInstanceSummary, ...],
) -> tuple[str, ...]:
    target_labels = _teacher_instance_labels(activity, items)
    labels: list[str] = []
    for target_label, item in zip(target_labels, items, strict=True):
        filename: str | None = None
        if item.output_relative_path:
            candidate = Path(item.output_relative_path).name
            if item.packet_instance_id not in candidate:
                filename = candidate
        if filename is None:
            labels.append(f"{target_label} - Ready to print")
        else:
            labels.append(f"{target_label} - {filename} - Ready to print")
    return tuple(labels)


def _choose_ready_instance(
    activity: ActivitySummary,
    *,
    title: str,
    generation_id: str | None = None,
) -> PacketInstanceSummary:
    items = _ready_packet_instances(
        activity,
        generation_id=generation_id,
    )
    if not items:
        raise ConcordWorkflowError(
            "No rendered Packet outputs are ready to open. "
            "Use Render / reprint to create or restore the output."
        )
    return select_one(
        title,
        items,
        _ready_instance_labels(activity, items),
        help_text=(
            "Choose the classroom material to open. Concord verifies the current "
            "recorded output and SHA-256 before requesting the system viewer."
        ),
    )


def _open_ready_packet(
    activity: ActivitySummary,
    *,
    generation_id: str | None = None,
) -> None:
    try:
        selected = _choose_ready_instance(
            activity,
            title="Open Rendered Packet",
            generation_id=generation_id,
        )
        open_rendered_packet_output(
            activity.class_id,
            activity.activity_id,
            selected.packet_instance_id,
        )
        label = _teacher_instance_labels(activity, (selected,))[0]
        show_result(
            "Open Rendered Packet",
            (
                f"Requested viewer opening for: {label}",
                "The OS accepted the request; this does not prove "
                "the PDF was displayed.",
            ),
        )
    except CancelMenuAction:
        return
    except Exception as error:
        show_result("Open Rendered Packet", (str(error),))


def _open_ready_folder(
    activity: ActivitySummary,
    *,
    generation_id: str | None = None,
) -> None:
    try:
        items = _ready_packet_instances(
            activity,
            generation_id=generation_id,
        )
        if not items:
            raise ConcordWorkflowError(
                "No rendered Packet outputs are ready to open. "
                "Use Render / reprint to create or restore the output."
            )
        anchor = items[-1]
        open_rendered_packet_output_directory(
            activity.class_id,
            activity.activity_id,
            anchor.packet_instance_id,
        )
        show_result(
            "Open Rendered Packet Folder",
            (
                "Requested opening of the verified rendered-Packet folder.",
                "This does not prove the folder was displayed.",
                "This is a local viewing/printing folder, not a share-safe export.",
            ),
        )
    except Exception as error:
        show_result("Open Rendered Packet Folder", (str(error),))


def launch_prepared_materials_menu(
    activity: ActivitySummary,
    state: MenuSessionContext,
) -> None:
    """Open prepared classroom materials without exposing storage internals."""
    while True:
        try:
            items = list_packet_instances(activity.class_id, activity.activity_id)
        except Exception as error:
            show_result("Prepared Materials", (str(error),))
            return
        if not items:
            show_result(
                "Prepared Materials",
                ("No classroom materials have been prepared yet.",),
            )
            return

        ready_count = sum(
            1 for item in items if item.generation_status == "generated"
        )
        attention_count = len(items) - ready_count
        clear_screen()
        print_menu_header("Prepared Materials")
        print(f"Activity: {activity.title}")
        print(f"Ready to print: {ready_count}")
        if attention_count:
            print(f"Need attention: {attention_count}")
        print()
        print("1. Open one ready PDF")
        print("2. Open rendered output folder")
        print("3. View preparation status")
        print("4. Prepare / generate / reprint")
        print_navigation()
        print()
        choice = input("Select an option: ").strip()
        navigation = parse_menu_navigation(choice)
        if navigation is ConcordMenuChoice.HELP:
            clear_screen()
            print_menu_header("Prepared Materials Help")
            print("Open verifies current Concord output state before launching it.")
            print("Open does not render, reprint, repair, or record viewed state.")
            print("Use Render / reprint when an output is missing or must be rebuilt.")
            print()
            pause_for_user()
        elif navigation is NavigationChoice.BACK:
            return
        elif choice == "1":
            _open_ready_packet(activity)
        elif choice == "2":
            _open_ready_folder(activity)
        elif choice == "3":
            show_prepared_materials(activity)
        elif choice == "4":
            launch_packet_generation_menu(activity, state)
        else:
            print(navigation_hint_with_help())
            pause_for_user()


def _list_instances(activity: ActivitySummary) -> None:
    try:
        items = list_packet_instances(activity.class_id, activity.activity_id)
        target_labels = _teacher_instance_labels(activity, items)
        lines = (
            distinguish_equal_labels(tuple(
                f"{target} | {item.audience_kind.replace('_', ' ')} | "
                f"{item.generation_status.replace('_', ' ')} | "
                f"{item.page_count} pages | "
                f"{teacher_recorded_instant(item.created_at, kind='Created')}"
                for target, item in zip(target_labels, items, strict=True)
            ), noun="copy")
            if items else (
                "No Packet Instances have been generated for this Activity.",
            )
        )
        show_result("Packet Instances", lines)
    except Exception as error:
        show_result("Packet Instance Error", (str(error),))


def _generation_state_label(
    item: PacketGenerationSummary,
) -> str:
    if item.routes_pending_count:
        return "Route recovery required"
    if item.planned_count or item.failed_count or item.cancelled_count:
        return "Needs attention"
    if item.generated_count == item.instance_count:
        return "Ready to reprint"
    if (
        item.rendering_count > 0
        and item.generated_count + item.rendering_count == item.instance_count
    ):
        return "Ready to render"
    return "Needs attention"


def _choose_generation(
    activity: ActivitySummary,
    *,
    title: str,
) -> PacketGenerationSummary:
    items = list_packet_generations(activity.class_id, activity.activity_id)
    if not items:
        raise ConcordWorkflowError("No Packet generations are available.")
    base_labels = tuple(
        f"{item.packet_name} - {item.session_label} | "
        f"{item.instance_count} Packets - {item.page_count} pages - "
        f"{_generation_state_label(item)} | "
        f"{teacher_planned_date(item.generation_date)} | "
        f"{teacher_recorded_instant(item.created_at, kind='Created')}"
        for item in items
    )
    labels = distinguish_equal_labels(base_labels, noun="generation")
    return select_one(
        title,
        items,
        labels,
        help_text=(
            "Choose the exact Packet generation. Planned date and actual created "
            "time are different; repeated runs may share a planned date."
        ),
    )


def _render_generation(
    activity: ActivitySummary,
    state: MenuSessionContext,
) -> None:
    try:
        selected = _choose_generation(
            activity,
            title="Render / Reprint Complete Generation",
        )
        if selected.routes_pending_count:
            show_result(
                "Packet Generation Requires Route Recovery",
                (
                    f"Packet: {selected.packet_name}",
                    f"Session: {selected.session_label}",
                    f"Packets awaiting routes: {selected.routes_pending_count}",
                    "Use Resume incomplete route preparation before rendering.",
                ),
            )
            return

        if (
            selected.planned_count
            or selected.failed_count
            or selected.cancelled_count
        ):
            show_result(
                "Packet Generation Requires Attention",
                (
                    f"Packet: {selected.packet_name}",
                    f"Session: {selected.session_label}",
                    f"Planned: {selected.planned_count}",
                    f"Failed: {selected.failed_count}",
                    f"Cancelled: {selected.cancelled_count}",
                    "The complete generation will not be subset-rendered.",
                ),
            )
            return

        if selected.generated_count == selected.instance_count:
            action = "REPRINT"
            title = "Reprint Packet Generation"
            identity_line = (
                "Existing Packet, Artifact, Page, and PDS2 route identities "
                "will be reused."
            )
        elif (
            selected.rendering_count > 0
            and selected.generated_count + selected.rendering_count
            == selected.instance_count
        ):
            action = "RENDER"
            title = "Render Packet Generation"
            identity_line = (
                "Prepared Packet, Artifact, Page, and PDS2 route identities "
                "will be rendered without replacement allocation."
            )
        else:
            show_result(
                "Packet Generation Requires Attention",
                (
                    f"Packet: {selected.packet_name}",
                    f"Session: {selected.session_label}",
                    "Generation state is not eligible for complete rendering.",
                ),
            )
            return

        if not confirm_write(
            title,
            action,
            (
                f"Packet: {selected.packet_name}",
                f"Version: {selected.packet_version_label}",
                f"Session: {selected.session_label}",
                f"Packet outputs: {selected.instance_count}",
                f"Pages: {selected.page_count}",
                f"Routes: {selected.route_count}",
                identity_line,
            ),
        ):
            return

        result = render_packet_generation(
            RenderPacketGenerationRequest(
                class_id=activity.class_id,
                activity_id=activity.activity_id,
                generation_id=selected.generation_id,
                actor=state.require_actor(),
                expected_snapshot_revision=selected.snapshot_revision,
            )
        )
        show_result(
            "Packet Generation Render Result",
            (
                f"Packet: {selected.packet_name}",
                f"Session: {selected.session_label}",
                f"Packet outputs: {len(result.packets)}",
                f"Pages: {result.page_count}",
                f"Routes: {result.route_count}",
                f"Operation: {'Reprint' if action == 'REPRINT' else 'Render'}",
            ),
        )
    except CancelMenuAction:
        return
    except PacketGenerationRenderPartialSuccessError as error:
        show_result(
            "Packet Generation Rendering Incomplete",
            (
                str(error),
                f"Completed outputs: {len(error.completed)}",
                "Completed PDFs remain durable.",
                "Retry the complete generation to verify and finish it.",
            ),
        )
    except PacketGenerationLifecyclePartialSuccessError as error:
        show_result(
            "Packet Generation Lifecycle Incomplete",
            (
                str(error),
                f"Durable outputs: {len(error.completed)}",
                (
                    "The PDFs are durable; canonical lifecycle reconciliation "
                    "is incomplete."
                ),
                "Retry the complete generation to reconcile lifecycle state.",
            ),
        )
    except Exception as error:
        show_result("Packet Generation Rendering Error", (str(error),))


def _choose_instance(
    activity: ActivitySummary,
    *,
    title: str,
) -> PacketInstanceSummary:
    items = list_packet_instances(activity.class_id, activity.activity_id)
    if not items:
        raise ConcordWorkflowError("No Packet Instances are available.")
    target_labels = _teacher_instance_labels(activity, items)
    base_labels = tuple(
        f"{target} | {item.generation_status.replace('_', ' ')} | "
        f"{item.page_count} pages | "
        f"{teacher_recorded_instant(item.created_at, kind='Created')}"
        for target, item in zip(target_labels, items, strict=True)
    )
    return select_one(
        title,
        items,
        distinguish_equal_labels(base_labels, noun="copy"),
        help_text=(
            "Choose the intended audience and creation time. "
            "Numbered copies are not chronological rankings."
        ),
    )


def _inspect_instance(activity: ActivitySummary) -> None:
    try:
        selected = _choose_instance(activity, title="Choose Packet Instance")
        detail = show_packet_instance(
            activity.class_id,
            activity.activity_id,
            selected.packet_instance_id,
        )
        item = detail.summary
        target_label = _teacher_instance_labels(activity, (item,))[0]
        lines = (
            f"Audience: {target_label}",
            f"Audience kind: {item.audience_kind.replace('_', ' ')}",
            f"Status: {item.generation_status.replace('_', ' ')}",
            teacher_recorded_instant(item.created_at, kind="Created"),
            f"Artifacts: {item.artifact_count}",
            f"Pages: {item.page_count}",
            f"Routes: {item.route_count}",
            "Output ready: " + ("yes" if item.output_relative_path else "no"),
            "Technical identifiers, paths and checksums are hidden from this view.",
        )
        show_result("Packet Instance", lines)
    except CancelMenuAction:
        return
    except Exception as error:
        show_result("Packet Instance Error", (str(error),))


def _render_instance(
    activity: ActivitySummary,
    state: MenuSessionContext,
) -> None:
    try:
        selected = _choose_instance(activity, title="Render / Reprint Packet")
        action = "REPRINT" if selected.generation_status == "generated" else "RENDER"
        if not confirm_write(
            "Render / Reprint Packet",
            action,
            (
                f"Packet Instance: {selected.packet_instance_id}",
                f"Target: {selected.target_key}",
                f"Status: {selected.generation_status}",
                (
                    "Existing PDS2 route identities will be reused."
                    if selected.generation_status == "generated"
                    else "Prepared PDS2 route identities will be rendered."
                ),
            ),
        ):
            return
        result = render_packet_instance(
            RenderPacketInstanceRequest(
                class_id=activity.class_id,
                activity_id=activity.activity_id,
                packet_instance_id=selected.packet_instance_id,
                actor=state.require_actor(),
            )
        )
        show_result(
            "Packet Render Result",
            (
                f"Output: {result.output_path}",
                f"Output SHA-256: {result.output_sha256}",
                f"Pages: {result.page_count}",
                f"Routes: {result.route_count}",
                f"Reprint: {'yes' if result.replayed else 'no'}",
            ),
        )
    except CancelMenuAction:
        return
    except PacketRenderPartialSuccessError as error:
        show_result(
            "Packet Rendering Partial Success",
            (
                str(error),
                f"Output: {error.result.output_path}",
                "The PDF is durable; retry to reconcile lifecycle state.",
            ),
        )
    except Exception as error:
        show_result("Packet Rendering Error", (str(error),))


def _resume_generation(activity: ActivitySummary) -> None:
    try:
        items = list_packet_instances(activity.class_id, activity.activity_id)
        generation_ids = tuple(
            dict.fromkeys(
                item.generation_id
                for item in items
                if item.generation_status == "routes_pending"
            )
        )
        if not generation_ids:
            raise ConcordWorkflowError(
                "No Packet generations are waiting for route reconciliation."
            )
        generation_id = select_one(
            "Resume Packet Generation",
            generation_ids,
            generation_ids,
            help_text=(
                "Resume reconciles immutable Core PDS2 routes for already-durable "
                "Packet generation state."
            ),
        )
        result = resume_packet_instantiation(
            activity.class_id,
            activity.activity_id,
            generation_id,
        )
        show_result(
            "Packet Generation Recovery",
            (
                f"Generation: {result.generation_id}",
                f"Packet Instances: {len(result.packet_instance_ids)}",
                f"Routes: {result.routes_verified}/{result.routes_expected}",
                "Generation is ready for rendering.",
            ),
        )
    except CancelMenuAction:
        return
    except PacketInstantiationPartialSuccessError as error:
        show_result(
            "Packet Generation Partial Success",
            (
                str(error),
                f"Generation: {error.result.generation_id}",
                f"Stage: {error.stage}",
                (
                    f"Routes: {error.result.routes_verified}/"
                    f"{error.result.routes_expected}"
                ),
            ),
        )
    except Exception as error:
        show_result("Packet Generation Recovery Error", (str(error),))


__all__ = [
    "launch_packet_generation_menu",
    "launch_prepared_materials_menu",
]
